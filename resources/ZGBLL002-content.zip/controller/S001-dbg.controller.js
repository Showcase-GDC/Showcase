sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function(Controller) {
	"use strict";
	
	return Controller.extend("showcase.ZGBLL002.controller.S001", {

	});

});