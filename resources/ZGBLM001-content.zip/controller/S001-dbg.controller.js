sap.ui.define([
	"sap/ui/core/mvc/Controller"
], function (Controller) {
	"use strict";

	return Controller.extend("showcase.ZGBLM001.controller.S001", {
		onInit: function () {

		}
	});
});