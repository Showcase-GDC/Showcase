sap.ui.define(['sap/ovp/app/Component'], function(AppComponent) {
    return AppComponent.extend('showcase.zgblo001.Component', {
        
        metadata: {
            manifest: 'json'
        }
    });
});
